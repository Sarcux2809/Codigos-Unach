import { Module } from '@nestjs/common';
import { TcontroladorController } from 'src/tcontrolador/tcontrolador.controller';

@Module({
imports: [],
controllers: [TcontroladorController],
providers: [],

})
export class TmoduloModule {}

import { Controller, Get } from '@nestjs/common';

@Controller('tcontrolador')
export class TcontroladorController {
    @Get()
    getHola(): string {
        return 'hola mundo';
        }
    }
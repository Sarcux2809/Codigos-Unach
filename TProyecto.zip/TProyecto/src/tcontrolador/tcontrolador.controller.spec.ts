import { Test, TestingModule } from '@nestjs/testing';
import { TcontroladorController } from './tcontrolador.controller';

describe('TcontroladorController', () => {
  let controller: TcontroladorController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [TcontroladorController],
    }).compile();

    controller = module.get<TcontroladorController>(TcontroladorController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});

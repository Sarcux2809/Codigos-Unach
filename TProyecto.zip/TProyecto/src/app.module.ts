import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TcontroladorController } from './tcontrolador/tcontrolador.controller';
import { TmoduloModule } from './tmodulo/tmodulo.module';

@Module({
  imports: [TmoduloModule],
  controllers: [AppController, TcontroladorController],
  providers: [AppService],
})
export class AppModule {}

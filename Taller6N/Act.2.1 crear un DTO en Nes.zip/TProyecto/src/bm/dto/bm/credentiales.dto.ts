export class CredentialsDto {
    Id: string;
    user: string;
    password: string; 
}
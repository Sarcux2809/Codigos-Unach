import { Controller, Get, Post, Put, Delete, Req, Patch, Body, Param, } from '@nestjs/common';
import { CredentialsDto } from './credentiales.dto';


@Controller('api/v1/bm')
export class BmController {

    @Post('id/:id/User/:user/Password/:password')
    metedopost(@Param('id') id: string, @Param('user') user: string, @Param('password') password: string, @Body() credentialsDto: CredentialsDto) {
        console.log('Id:', id);
        console.log('User:', user);
        console.log('Password:', password);
        // Aquí puedes hacer lo que necesites con el Id, usuario, contraseña y otros datos
        return { Id: id, user, password }; 
    }

    @Get('getruta') 
    getMethod(@Req() req: Request) {
        return `método ${req.method}`;
    }

    @Put()
    metodoput(@Req() req: Request) {
        return `método ${req.method}`;
    }
    
    @Delete()
    metododelete(@Req() req: Request) {
        return `método ${req.method}`;
    }

    @Patch()
    metodopatch(@Req() req: Request) {
        return `método ${req.method}`;
    }
}

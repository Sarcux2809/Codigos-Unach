import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TcontroladorController } from './tcontrolador/tcontrolador.controller';
import { TmoduloModule } from './tmodulo/tmodulo.module';
import { BmController } from './bm/dto/bm/bm.controller';
import { BmModule } from './bm/dto/bm/bm.module';
import { BmService } from './bm/dto/bm/bm.service';

@Module({
  imports: [TmoduloModule, BmModule], 
  controllers: [AppController, TcontroladorController, BmController],
  providers: [AppService, BmService] 
})
export class AppModule {}
